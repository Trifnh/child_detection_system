# AI Design Workflow for GitHub Copilot

Evidence-first workflow for generating and validating Japanese-customer-style software Detail Design documents with GitHub Copilot.

## Components

- **Design Agent**: analyzes specifications, approved samples, old designs, and source code; then generates a Detail Design.
- **Review Agent**: validates requirement coverage, evidence, consistency, style, and traceability without editing the Design.
- **Update Agent**: applies only evidence-supported review findings and creates an update log.
- **Shared Skill**: reusable Detail Design template, classification rules, and review checklist.

## Quick start

1. Put new customer specifications and task lists in `docs/specs/new/`.
2. Put old specifications in `docs/specs/old/`.
3. Put approved Design samples in `docs/design/samples/`.
4. Copy `docs/design-agent/input-manifest.template.yaml` to `docs/design-agent/input-manifest.yaml` and update the paths.
5. Reload VS Code.
6. Run the Copilot prompt sequence:
   - `/design-analyze`
   - `/design-generate`
   - `/design-review`
   - `/design-update`
   - `/design-review`

See [`docs/design-agent/README.md`](docs/design-agent/README.md) for the complete workflow.

## V2 sample-first profile

For camera/clip compatibility documents that must follow a human-written sample, use `strict_sample_format: true` and `source_code_required: false` in the manifest. See `docs/design-agent/README-v2.md`.
