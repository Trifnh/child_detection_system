# V2 — Sample-First Design Workflow

## Why V1 generated a poor document

V1 treated the final output as an evidence/implementation report. This caused:

- generic analysis sections,
- content unlike the approved sample,
- implementation details without evidence,
- invented UI fields and processing behavior,
- missing exact tables from the customer specification.

V2 separates the two artifacts:

1. Analysis file: requirements, task coverage, conflicts, and generation contract.
2. Final Design: only customer-facing functional content following the approved sample.

## Required setup

1. Put the customer spec in `docs/specs/new/`.
2. Put the task list in `docs/specs/new/`.
3. Put the approved human sample in `docs/design/samples/`.
4. Copy `input-manifest.template.yaml` to `input-manifest.yaml`.
5. Set `strict_sample_format: true`.
6. Set `source_code_required: false` for spec-level compatibility Design.

## Run

1. New chat → `/design-analyze`
2. Check analysis:
   - exact sample outline,
   - complete task coverage,
   - correct technical values/tables,
   - no invented details.
3. New chat → `/design-generate`
4. New chat → `/design-review`
5. If FAIL → `/design-update`
6. Run `/design-review` again.

## Expected final document

The final document should look like the approved sample, not like an AI analysis report.
