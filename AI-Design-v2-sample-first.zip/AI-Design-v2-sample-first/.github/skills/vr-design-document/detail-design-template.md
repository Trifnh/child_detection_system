# Sample-First Detail Design Template

This file is a fallback only. When an approved sample is supplied and `strict_sample_format: true`, the approved sample overrides this template.

# <Version> <Task title><!-- omit in toc -->
---

## Table of Contents<!-- omit in toc -->
---

Generate the TOC from the actual headings using the same formatting as the approved sample.

----
# 1. Overview

Write a concise purpose paragraph for the current compatibility/support task.

## 1.1. Related Documents

|No.|File Name|Contents|Revision|
| - | - | - | - |

## 1.2. Functional Overview

Summarize existing functions reused and new technical values introduced by the current specification.

## 1.3. Supported Scope

- OS
- Languages
- Models/lenses/formats

## 1.4. Development Environment

Use only information explicitly provided by the inputs. Otherwise keep the approved sample's placeholder style.

---
# 2. <Functional compatibility title>

Create functional sections in the same order/style as the approved sample. For camera/clip compatibility tasks, typically include:

- Lens + camera support
- Clip List Pane
- Metadata Pane
- Viewer Pane — video
- Viewer controls and preview formats
- Viewer Pane — still image
- Parameter Setting Pane — VR correction
- Parameter Setting Pane — RAW development
- Export image and subformats
- Export video and subformats

For each section, directly state:

- current behavior,
- new-target behavior,
- confirmation points,
- relevant source tables.

Do not insert generic analysis-framework headings.

---
# Notes

Summarize the compatibility focus and key confirmation points in the approved sample's style.
