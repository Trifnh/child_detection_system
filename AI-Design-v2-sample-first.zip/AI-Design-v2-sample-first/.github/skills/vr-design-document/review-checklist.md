# Design Review Checklist — Sample-First Compatibility Design

Score each category from 0 to 5.

## A. Sample Format Compliance

- Title style matches the approved sample.
- Table of Contents style matches.
- Heading hierarchy and ordering match.
- Captions, tables, bullets, and Notes style match.
- No extra meta sections absent from the sample.

## B. Task Coverage

- Every task-list item is explicitly covered.
- Viewer controls are not collapsed into one vague statement.
- VR correction functions are individually covered.
- RAW-processing functions are individually covered.
- Metadata and export items are explicitly covered.

## C. Technical Accuracy

- Target model is correct.
- Lens combinations are exact.
- MP4/CRM/JPEG and RAW-processing concepts are not confused.
- Resolutions, frame rates, preview formats, and output mappings match the current spec.
- T.B.D. values remain T.B.D.

## D. Zero Invention

- No invented UI fields.
- No invented algorithms or processing flow.
- No invented SDK artifacts.
- No invented performance requirements.
- No invented warnings/errors/fallbacks.

## E. Language and Terminology

- Vietnamese is clear and technical.
- Official Japanese UI labels are preserved.
- Technical keywords are consistent.
- No awkward generated/reporting language.

## F. Table Integrity

- Relevant tables are present.
- Table symbols and notes are preserved.
- No missing or invented cells.
- Table numbering and references are consistent.

## Decision

- `PASS`: 30/30 preferred; minimum 27/30, with no BLOCKER and no unsupported assertion.
- `FAIL`: any wrong model/lens/format, invented behavior, missing mandatory task group, or materially different sample format.
