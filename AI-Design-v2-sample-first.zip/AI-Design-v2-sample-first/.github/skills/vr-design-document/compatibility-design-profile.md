# Compatibility Design Profile

Use this profile when the task adds or confirms support for a new camera, lens, clip format, resolution, frame rate, or media combination while reusing existing application functions.

## Document purpose

The final document is a customer-facing functional Detail Design derived from:

1. the new customer specification,
2. the task/work-item list,
3. an approved human-written sample document.

It is not a repository investigation report and not an implementation-change proposal unless the input explicitly requests code-level design.

## Structural contract

When `strict_sample_format: true`, the approved sample is the structural contract.

The final document must reproduce the sample's:

- title style,
- Table of Contents style,
- heading hierarchy,
- section order,
- table-caption style,
- bullet style,
- terminology style,
- Notes section style.

Do not copy task-specific facts from the sample. Replace them with facts from the current specification.

## Default compatibility-document structure

Use this structure when it matches the approved sample:

1. Overview
   - Related Documents
   - Functional Overview
   - Supported Scope
   - Development Environment
2. Functional compatibility of the target model/format
   - Camera/lens support
   - Clip List Pane
   - Metadata Pane
   - Viewer Pane: video mode
   - Viewer controls
   - Preview play formats
   - Viewer Pane: still-image mode
   - Parameter Setting Pane: VR correction
   - Parameter Setting Pane: RAW development/processing
   - Export image
   - Export video
3. Notes

Create only sections supported by the current task list or specification. Keep section ordering aligned with the approved sample.

## Content pattern

Within each functional section, write directly in the approved sample's style:

- existing behavior,
- support behavior for the new target,
- confirmation points,
- technically relevant tables.

Do not add repetitive subheadings such as `Current Specification`, `Support Policy`, `Design Details`, `Impact`, or `Confirmation Items` unless the approved sample uses them.

## Table policy

- Preserve all values, symbols, conditions, notes, and T.B.D. labels from the customer specification.
- Copy or reconstruct the relevant table at the same logical location as the approved sample.
- Correct malformed Markdown/HTML only structurally.
- Do not invent missing table cells.
- Do not add unrelated legacy rows merely to make a table look complete.
- When the sample includes a full comparison matrix and the current spec provides the complete matrix, preserve it.

## Task-list coverage policy

Every task item must be represented in one of these ways:

1. a dedicated subsection,
2. an explicit bullet under the matching pane/function,
3. a table row,
4. a clearly identified T.B.D./confirmation item.

Do not replace multiple specific task items with a vague sentence such as "viewer behavior is confirmed".

## Forbidden final-document content

Unless explicitly present in the current specification or approved sample, do not add:

- Revision History,
- generation metadata,
- analysis-file links,
- source-code investigation sections,
- evidence IDs,
- requirement IDs,
- change classifications,
- file/symbol change lists,
- rollback plans,
- review scorecards,
- generic QA plans,
- product/QA workflow commentary.

These may exist in the analysis file, but not in the customer-facing Design.

## Forbidden technical inventions

Do not add any of the following unless explicitly stated in the current inputs:

- filename/timestamp/status fields,
- gyro-presence flags or gyro-based reprojection,
- metadata editing capability,
- proxy playback,
- fallback resolution,
- frame dropping or decimation,
- GPU/CPU/memory requirements,
- performance profiling,
- CRMSDK artifacts or guidance,
- WB, exposure compensation, demosaic mode,
- bitrate targets or encode presets,
- metadata passthrough,
- warning dialogs or error messages,
- project-file persistence,
- QA scripts,
- SDK deliverables.

## Semantic guards

- `CRM` is a clip/file format. Do not replace it with a generic `RAW` clip format unless the specification explicitly lists RAW as an input format.
- RAW development/processing is a function. It does not prove that the Clip List Pane displays a separate RAW format.
- A target-model support row must include only lens combinations explicitly supported for that target.
- If the task title says one model and a note says another, record a short confirmation note; do not spread the conflicting model throughout the document.
- "No new logic" means existing functions are reused. It does not authorize invented implementation details.
