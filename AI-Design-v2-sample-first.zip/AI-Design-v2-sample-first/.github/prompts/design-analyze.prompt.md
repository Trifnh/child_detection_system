---
name: design-analyze
description: Analyze the current specification, task list, and approved sample to create a strict generation contract.
agent: design-agent
model: GPT-5 mini (copilot)
---

Analyze the Design task using this manifest:

`${input:manifestPath:docs/design-agent/input-manifest.yaml}`

Run Stage 1 only.

The analysis must prioritize:

1. Exact approved-sample structure
2. Exact approved-sample writing style
3. Complete task-list coverage
4. Current-spec technical values and tables
5. Conflict and T.B.D. detection

Create the analysis file from the manifest.

Do not create the final Detail Design.
Do not edit source code.
Do not propose technical details that are not present in the inputs.
