---
name: design-generate
description: Generate a sample-faithful customer-facing Detail Design from the completed analysis.
agent: design-agent
model: GPT-5 mini (copilot)
---

Generate the final Detail Design using this manifest:

`${input:manifestPath:docs/design-agent/input-manifest.yaml}`

Mandatory procedure:

1. Read the manifest.
2. Read the completed analysis file.
3. Read the primary approved sample again in full.
4. Read the current new specification and task list again in full.
5. Use the approved sample as a strict structural and writing-style contract.
6. Use only the current specification/task list for task-specific facts.
7. Generate exactly one customer-facing Markdown document at `output_path`.

Mandatory output constraints:

- Do not create a Revision History unless the approved sample has one.
- Do not include analysis links, evidence matrices, classifications, rollback, traceability, or generic test plans unless the approved sample has them.
- Do not use generic per-pane subheadings such as `Current Specification`, `Support Policy`, `Design Details`, `Impact`, or `Confirmation Items` unless the approved sample has them.
- Preserve the sample's Table of Contents, section order, heading depth, captions, tables, bullets, and Notes style.
- Cover every task-list item.
- Preserve MP4/CRM/JPEG distinctions.
- Preserve exact model/lens combinations.
- Preserve all resolution, frame-rate, output-size, symbol, note, and T.B.D. values from the current spec.
- Do not invent fields, parameters, algorithms, performance requirements, SDK artifacts, warnings, fallbacks, or implementation behavior.
- When detail is absent, write only an existing-behavior reuse statement plus confirmation points.
- Do not edit source code.

Before saving, compare the draft against the approved sample and rewrite it if the structure or tone differs materially.
