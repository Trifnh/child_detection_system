# Project-wide Copilot Instructions

This repository uses an evidence-first workflow for software Design documents.

## General rules

- Treat customer specifications as requirements, not implementation evidence.
- Treat approved old specifications and approved sample Design documents as the baseline for format, terminology, and existing behavior.
- Treat source code, constants, enums, tables, mappings, and configuration files as implementation evidence.
- Never invent runtime behavior, error messages, warnings, fallback logic, performance limits, SDK behavior, or source locations.
- Preserve values marked `T.B.D.` as unresolved.
- When names or identifiers conflict, record `NEED_CONFIRMATION`; do not silently correct them.
- Keep official Japanese UI labels, product names, format names, symbols, and terminology unchanged.
- Every asserted code change must include an exact repository path and symbol.
- If evidence is unavailable, use `TBD_NO_EVIDENCE`.
- Design documents must clearly separate:
  - current behavior,
  - new requirement,
  - design decision,
  - actual modification,
  - impact,
  - confirmation items.
- Use a conservative Japanese corporate technical-writing style: objective, concise, traceable, and free of promotional language.
- Do not modify application source code when the task is Design-document generation, review, or update.
