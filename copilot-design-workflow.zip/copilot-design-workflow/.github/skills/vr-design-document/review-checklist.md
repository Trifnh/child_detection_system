# Design Review Checklist

Score each category from 0 to 5.

## A. Requirement Coverage
- Every task/work item has a requirement ID.
- Every requirement appears in the design or Open Points.
- No task item is silently omitted.

## B. Factuality and Evidence
- Every claimed code change has an exact path and symbol.
- No speculative runtime behavior is introduced.
- All `T.B.D.` values remain unresolved.
- Contradictions are marked `NEED_CONFIRMATION`.

## C. Design Completeness
- Current behavior and new behavior are separated.
- Classification is valid.
- Data/mapping changes are explicit.
- Impact and regression scope are present.
- Validation items are derived from requirements/design.

## D. Consistency
- Model, lens, format, resolution, and frame-rate names are consistent.
- Section numbering and table numbering are consistent.
- Official UI terms are consistent.
- Symbols such as `○`, `●`, `×`, and `—` retain their meanings.

## E. Japanese Customer Style
- Objective and concise wording.
- No conversational or promotional language.
- One fact per sentence.
- Clear current/policy/design/impact/confirmation pattern.
- No unnecessary duplication of the customer specification.

## F. Traceability
- Requirement → evidence → design → validation mapping is complete.
- Related documents have exact names/revisions when available.
- Missing evidence is explicit.

## Severity

- `BLOCKER`: wrong model/task, invented behavior, missing core function, or destructive inconsistency.
- `MAJOR`: incomplete requirement coverage, unsupported design decision, broken traceability, or incorrect mapping.
- `MINOR`: wording, table formatting, terminology, numbering, or non-critical omission.
- `INFO`: optional improvement.

## Decision

- `PASS`: no BLOCKER, no MAJOR, total score >= 26/30.
- `CONDITIONAL_PASS`: no BLOCKER, at most 2 MAJOR, total score >= 22/30.
- `FAIL`: any BLOCKER, more than 2 MAJOR, or score < 22/30.
