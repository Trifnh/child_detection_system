---
name: vr-design-document
description: Evidence-first workflow for analyzing, generating, reviewing, and updating Japanese-customer-style software Detail Design documents from customer specifications, approved samples, old specifications, and source code.
argument-hint: "[manifest path or design document path]"
---

# VR Design Document Skill

Use this skill for Design-document tasks involving camera models, lenses, media clips, metadata, viewer behavior, parameter settings, RAW processing, VR correction, image/video export, output-size mapping, or compatibility validation.

Read the supporting resources in this skill directory:

- [Detail Design template](./detail-design-template.md)
- [Change classification rules](./classification-rules.md)
- [Review checklist](./review-checklist.md)

## Required reasoning sequence

1. Validate the input manifest and referenced paths.
2. Read the complete new customer specification.
3. Read task/work-item lists supplied by the user.
4. Read one or more approved sample Design documents.
5. Derive a style profile from approved samples:
   - title and heading convention,
   - table convention,
   - language and terminology,
   - section ordering,
   - level of detail,
   - use of current/new/confirmation distinctions.
6. Extract a requirement inventory.
7. Detect contradictions, including model-name mismatches.
8. Search old specifications and source code using dynamic keywords extracted from the current task.
9. Build an evidence matrix.
10. Classify every requirement.
11. Generate or review the document.
12. Run the completion checklist.

## Dynamic requirement extraction

Extract only values explicitly present in current inputs:

- Task ID and product version
- Camera and lens models
- Clip/file formats
- Resolutions and frame rates
- Codec/RAW types
- Target panes and functions
- Preview modes and controls
- Parameter-setting functions
- Metadata behavior
- Export formats and output-size rules
- OS/language scope
- Limitations
- T.B.D. items
- Explicit no-change or confirmation-only statements

Do not reuse model names or values from a previous task unless the current input references them.

## Dynamic search strategy

Search exact identifiers first, then related behavior:

- new camera/lens identifiers,
- similar older camera/lens combinations,
- format and extension names,
- resolution and frame-rate values,
- UI labels,
- parser/formatter terms,
- support tables and mappings,
- preview/viewer terms,
- correction and RAW terms,
- export/output-size/APMP terms.

A new model may not exist in old files. In that case, find the nearest existing implementation by matching lens, format, resolution family, or function.

## Evidence standard

Document evidence must include:

- exact document path,
- exact heading/table/section,
- relevant behavior.

Code evidence must include:

- exact source path,
- class/module,
- method/function/constant/enum/table/symbol,
- relevant current condition,
- relationship to the requirement.

A generic statement such as "existing logic supports it" is not evidence.

## Japanese-customer-style writing

For each functional area, prefer:

1. `Current Specification / 現行仕様`
2. `Support Policy / 対応方針`
3. `Design Details / 設計内容`
4. `Impact / 影響範囲`
5. `Confirmation Items / 確認項目`

Use short, objective sentences.

Preferred expressions:

- "The existing processing is reused."
- "No functional change is required."
- "The following entry is added."
- "This item is subject to operation confirmation."
- "The implementation location was not identified."
- "Customer confirmation is required."

Avoid speculative expressions such as "probably", "should automatically", or "expected to work" without evidence.

## Critical semantic rules

- "Result is not guaranteed" does not mean "the function is disabled."
- "Existing logic is reused" does not prove zero code change.
- "Validation required" does not automatically imply implementation change.
- "Not supported" does not imply a warning dialog unless specified.
- `T.B.D.` must remain unresolved.
- A typo or inconsistent model identifier must be flagged, not silently normalized.
