# Adaptive Detail Design Template

Do not create empty sections. Adapt the functional subsections to the current task and approved sample style.

# <Task ID> <Main Subject> Detail Design

## 1. Overview

### 1.1 Purpose
### 1.2 Scope
### 1.3 Out of Scope
### 1.4 Related Documents

## 2. Requirement and Task Coverage

| ID | Task/Requirement | Source | Target Area | Status |
|---|---|---|---|---|

Include every work item supplied for the Design task.

## 3. Investigation Result

### 3.1 Sample Design Style Profile
### 3.2 Existing Specification Evidence
### 3.3 Source-Code Evidence
### 3.4 Missing Evidence and Conflicts

## 4. Design Summary

| Area | Classification | Design Summary | Evidence |
|---|---|---|---|

## 5. Detailed Design

Create subsections dynamically, for example:

- Camera and lens support
- Clip list: still/video
- Clip list: thumbnail/list
- Viewer: still preview
- Viewer: video preview formats
- Viewer: 100%, 1/2, 1/4, FULL
- Viewer: resize
- Viewer: mini map
- Viewer: new resolution
- VR correction: export format
- VR correction: parallax correction
- VR correction: stabilization
- VR correction: lens mask
- VR correction: horizontal correction
- RAW processing
- Fast processing
- Lens adjustment
- Metadata for MP4 export
- Image export
- Video export
- New output-resolution handling

Each subsection uses:

### Current Specification / 現行仕様
### Support Policy / 対応方針
### Design Details / 設計内容
### Impact / 影響範囲
### Confirmation Items / 確認項目

## 6. File and Symbol Change List

| No. | File | Symbol | Classification | Change Description | Requirement ID |
|---|---|---|---|---|---|

If exact evidence is unavailable, do not fabricate rows.

## 7. Data and Mapping Definitions

Include only affected camera/lens matrices, resolution/frame-rate values, feature matrices, preview mappings, and export mappings.

## 8. Processing Flow

Describe only evidence-supported flows.

## 9. Error Handling and Limitations

Use only behavior found in current inputs or source evidence.

## 10. Impact Analysis

| Area | Direct Impact | Existing Behavior to Preserve | Regression Confirmation |
|---|---|---|---|

## 11. Validation Matrix

| No. | Requirement ID | Function | Input/Condition | Expected Result | Basis |
|---|---|---|---|---|---|

## 12. Traceability Matrix

| Requirement ID | Input Source | Evidence ID | Design Section | Validation Item |
|---|---|---|---|---|

## 13. Open Points

Include only conflicts, T.B.D. values, missing evidence, missing sample clips, and customer-confirmation items.

## Appendix

Include only essential tables. Correct malformed Markdown/HTML without changing values or symbols.
