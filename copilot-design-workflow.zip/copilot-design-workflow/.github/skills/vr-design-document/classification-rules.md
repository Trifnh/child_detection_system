# Change Classification Rules

Use exactly one primary classification per requirement.

| Classification | Meaning | Required evidence |
|---|---|---|
| `ADD_DATA` | Add a camera/lens entry, enum, constant, mapping, supported value, or configuration row. | Exact table/symbol or `TBD_NO_EVIDENCE` if not found. |
| `MODIFY_LOGIC` | Change a condition, branch, algorithm, processing flow, or behavior. | Exact file and method/function. |
| `MODIFY_UI` | Change UI layout, control state, displayed value, or interaction. | Exact view/controller/resource/symbol. |
| `NO_CHANGE` | Existing implementation demonstrably supports the requirement. | Existing spec and/or code evidence proving support. |
| `CONFIRM_ONLY` | Existing behavior is intended to be reused and only operation confirmation is required. | Requirement statement plus no blocking condition found. |
| `TBD_NO_EVIDENCE` | Related implementation or baseline cannot be identified. | List searched locations/keywords. |
| `NEED_CONFIRMATION` | Inputs conflict, are ambiguous, or contain unresolved terminology. | Cite both conflicting inputs. |

Do not use vague labels such as `small update`, `minor change`, or `probably supported`.

## Decision order

1. Is there a conflict or ambiguity? → `NEED_CONFIRMATION`
2. Is implementation evidence missing? → `TBD_NO_EVIDENCE`
3. Does a processing condition change? → `MODIFY_LOGIC`
4. Does UI behavior/layout change? → `MODIFY_UI`
5. Is only a data/mapping entry added? → `ADD_DATA`
6. Is existing support proven? → `NO_CHANGE`
7. Is the requirement explicitly confirmation of reused behavior? → `CONFIRM_ONLY`
