---
name: design-update
description: Apply valid review findings to a Detail Design and create an update log.
agent: design-update-agent
model: GPT-5 mini (copilot)
---

Update the Design using:

Manifest:
`${input:manifestPath:docs/design-agent/input-manifest.yaml}`

Design document:
`${input:designPath:docs/design/generated/DetailDesign.md}`

Review report:
`${input:reviewPath:docs/design/reviews/DetailDesign.review.md}`

Update log:
`${input:updateLogPath:docs/design/reviews/DetailDesign.update-log.md}`

Apply only evidence-supported findings.
Keep unresolved issues as Open Points.
Do not edit source code.
