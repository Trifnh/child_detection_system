---
name: design-analyze
description: Analyze Design inputs, sample style, requirements, old specifications, and source evidence without generating the final Design.
agent: design-agent
model: GPT-5 mini (copilot)
---

Analyze the Design task using this manifest:

`${input:manifestPath:docs/design-agent/input-manifest.yaml}`

Run Stage 1 only.

Create the analysis file defined in the manifest.

Do not create or edit the final Design document.
Do not edit source code.

The analysis must include complete task coverage, identifier-conflict detection, sample-style analysis, evidence matrices, classifications, and a proposed document outline.
