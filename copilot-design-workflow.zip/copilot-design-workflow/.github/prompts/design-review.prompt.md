---
name: design-review
description: Review a generated Detail Design and create an evidence-based review report.
agent: design-review-agent
model: GPT-5 mini (copilot)
---

Review the Design workflow using:

Manifest:
`${input:manifestPath:docs/design-agent/input-manifest.yaml}`

Design document:
`${input:designPath:docs/design/generated/DetailDesign.md}`

Review report output:
`${input:reviewPath:docs/design/reviews/DetailDesign.review.md}`

Do not edit the Design document.
Apply the full review checklist.
Return PASS, CONDITIONAL_PASS, or FAIL with atomic findings.
