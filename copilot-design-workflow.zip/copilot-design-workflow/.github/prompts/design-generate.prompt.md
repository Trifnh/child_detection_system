---
name: design-generate
description: Generate the final Detail Design after the evidence analysis is complete.
agent: design-agent
model: GPT-5 mini (copilot)
---

Generate the Detail Design using this manifest:

`${input:manifestPath:docs/design-agent/input-manifest.yaml}`

Requirements:

1. Read the completed analysis file defined in the manifest.
2. Verify it contains requirement, task coverage, evidence, contradiction, and classification matrices.
3. Generate the Design at the manifest `output_path`.
4. Follow the approved sample style profile.
5. Cover all task-list items.
6. Do not edit source code.
7. Do not invent missing behavior.
8. Keep conflicts and T.B.D. items explicit.
