# Agent Evaluation Scorecard

Use this scorecard to test the agents with 1–2 approved sample tasks.

| Category | Weight | Measurement |
|---|---:|---|
| Requirement coverage | 20 | Percentage of task/spec requirements mapped to design |
| Factual accuracy | 20 | Unsupported assertions and incorrect values |
| Evidence traceability | 20 | Claims with exact document/code evidence |
| Design usefulness | 15 | DEV/UT/ITC can act on the output |
| Japanese-customer style | 10 | Objective, concise, consistent structure |
| Format correctness | 5 | Markdown, headings, tables, numbering |
| Review-agent detection | 5 | Known injected defects detected |
| Update-agent precision | 5 | Valid findings fixed without unrelated changes |

## Acceptance threshold

- Total score >= 85/100
- Requirement coverage = 100%
- Zero invented behavior
- Zero silent identifier normalization
- All BLOCKER and MAJOR review findings resolved
- Re-review decision = PASS
