# GitHub Copilot Design Workflow

## Architecture

1. `design-agent`
   - analyzes input,
   - derives style from approved samples,
   - searches old specs/source,
   - generates Detail Design.

2. `design-review-agent`
   - read-only,
   - independently checks coverage, evidence, format, and style,
   - creates a review report.

3. `design-update-agent`
   - applies valid review findings,
   - preserves unresolved items,
   - creates an update log.

4. `vr-design-document` skill
   - shared domain workflow,
   - template,
   - classification rules,
   - review checklist.

## Folder setup

Place files here:

- New customer spec: `docs/specs/new/`
- Task list: `docs/specs/new/`
- Old specs: `docs/specs/old/`
- Approved sample Designs: `docs/design/samples/`
- Existing reference Designs: `docs/design/reference/`
- Generated outputs: `docs/design/generated/`
- Review reports: `docs/design/reviews/`

Copy `input-manifest.template.yaml` to `input-manifest.yaml` and edit paths.

## VS Code setup

1. Open the repository root in VS Code.
2. Update VS Code and GitHub Copilot extensions.
3. Run `Developer: Reload Window`.
4. Open Copilot Chat.
5. Confirm GPT-5 mini is available in the model picker.
6. Right-click Chat → Diagnostics and verify agents, prompts, instructions, and skill loaded without errors.

If `GPT-5 mini (copilot)` is unavailable due to plan or organization policy, remove the `model` field temporarily and select an available model from the picker.

## Recommended run sequence

Use a new chat for each major stage.

1. `/design-analyze`
2. Human checks:
   - requirement inventory,
   - K535/K353 or other conflicts,
   - evidence paths,
   - classifications,
   - proposed outline.
3. `/design-generate`
4. `/design-review`
5. Human approves review findings.
6. `/design-update`
7. `/design-review` again.
8. Accept only after `PASS`.

## Mapping to the AI task plan

| AI Task | Deliverable |
|---|---|
| Analyze Design input/output | Manifest, analysis file, adaptive template, scorecard |
| Design prompt and workflow | Prompt files and staged workflow |
| Build Design Agent | `design-agent.agent.md` |
| Test with 1–2 samples | `sample-test-plan.md` |
| Apply to real project | Manifest + `/design-analyze` + `/design-generate` |
| Create Review Agent | `design-review-agent.agent.md` + `/design-review` |
| Create Update Agent | `design-update-agent.agent.md` + `/design-update` |
| Review output and refine | Scorecard, re-review loop, prompt-change rule |

## Quality gate

Do not accept a Design when:
- a task item is missing,
- a model/lens identifier conflict is hidden,
- a source change lacks exact path/symbol,
- runtime behavior is invented,
- a T.B.D. value is resolved without evidence,
- review decision is FAIL or CONDITIONAL_PASS.
