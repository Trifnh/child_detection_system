# Agent Test Plan

## Sample 1 — Golden-document reproduction

Input:
- Approved customer spec
- Approved human Design document
- Relevant old specs and source

Procedure:
1. Hide the approved Design output from the Design Agent.
2. Run `/design-analyze`.
3. Review analysis correctness.
4. Run `/design-generate`.
5. Compare generated output with the approved Design.
6. Run `/design-review`.

Measure:
- Requirement coverage
- Section/style similarity
- Correct classifications
- Evidence accuracy
- Hallucination count

## Sample 2 — Defect injection

Create a copy of a Design document and inject:
- wrong camera model,
- missing task item,
- invented warning dialog,
- incorrect resolution,
- broken traceability,
- inconsistent section number.

Run `/design-review`.

Expected:
- Wrong model: BLOCKER
- Invented behavior: BLOCKER/MAJOR
- Missing requirement: MAJOR
- Wrong value: MAJOR
- Traceability gap: MAJOR
- Numbering issue: MINOR

Then run `/design-update` and re-run `/design-review`.

## Refinement rule

Change prompts only when the same defect occurs in at least two runs or when a BLOCKER is missed once.
Record every prompt change and its before/after evaluation score.
